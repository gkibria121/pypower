 
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('fetchTimezoneButton').addEventListener('click', fetchIPandDisplayTimezone);
    document.getElementById('changeTimezoneButton').addEventListener('click', fetchIPandDisplayTimezone);
    
    // Display the current timezone when popup opens
    displayCurrentTimezone();
});

function fetchIPandDisplayTimezone() {
    chrome.runtime.sendMessage({action: "fetchTimezone"}, function(response) {
        if (chrome.runtime.lastError) {
            console.error(chrome.runtime.lastError);
        } else {
            console.log(response.status);
        }
    });
}

function displayCurrentTimezone() {
    chrome.runtime.sendMessage({action: "getTimezone"}, function(response) {
        document.getElementById('timezone').textContent = response.timezone;
    });
}

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.action === "timezoneUpdated") {
        document.getElementById('timezone').textContent = request.timezone;
    }
});
   