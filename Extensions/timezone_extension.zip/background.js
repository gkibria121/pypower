
chrome.runtime.onInstalled.addListener(() => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.scripting.executeScript(tabs[0].id, {
      code: `Object.defineProperty(navigator, 'userLanguage', { get: () => 'America/New_York' });`,
    });
  });
});

        